const { MongoClient } = require("mongodb");

exports.handler = async (event) => {
  try {
    const username = encodeURIComponent("JeetG-22");
    const password = encodeURIComponent("Jeet12345!");
    const mongodb_uri = `mongodb+srv://${username}:${password}@platepioneer.ilmm5.mongodb.net/?retryWrites=true&w=majority&appName=PlatePioneer`;

    const client = new MongoClient(mongodb_uri);
    const DB_NAME = "PlatePioneer";
    const bodyObject = JSON.parse(event.body || "{}");
    console.log(bodyObject);
    const user_id = bodyObject.authID;
    async function insertUser() {
      try {
        await client.connect();
        const database = client.db(DB_NAME);
        const users = database.collection("Users");
        await users.insertOne({
          user_auth_id: user_id,
          intake_status: false,
        });
      } finally {
        await client.close();
      }
    }
    await insertUser();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "User Added To DB" }),
    };
  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: error }),
    };
  }
};
